let url = "https://kontests.net/api/v1/all"

let response = fetch(url);
response.then((v) => {

  return v.json();

}).then((contest) => {
  console.log(contest);

  ihtml = ''

  for (item in contest) {
    console.log(contest[item]);

    ihtml += `
  <div class="card mx-2 my-2" style="width: 22rem;">
        <img  src="https://cosmosgroup.sgp1.cdn.digitaloceanspaces.com/news/9608604.webp" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">${contest[item].name}</h5>
          <p class="card-text"><a href="${contest[item].url}">Visit Here</a></p>
          <p>Start Time: ${contest[item].start_time}</p>
          <p>End Time: ${contest[item].end_time}</p>
          <p>Duration: ${contest[item].duration}</p>
          <p>Status: ${contest[item].status}</p>
          <p>In 24 Hours: ${contest[item].in_24_hours}</p>
          
          <a href="${contest[item].url}" class="btn btn-primary my-4">Visit Page Here</a>
        </div>
      </div>
  
  
  `

  }

  cardall.innerHTML = ihtml
})





//save note in localstorage


/*let b = localStorage.getItem("Note");
alert("Your Note is  "+b);
console.log("Your note is" + b)

let a = prompt("Enter you note");
if(a){ 
localStorage.setItem("Note", a);
}

//delete the note

let c = confirm("Do you want to delete the note");
if(c){
  localStorage.removeItem("Note");
  alert("Note Successfully Deleted..")
}*/

